import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";
import "aos/dist/aos.css";
import { useEffect } from "react";
import Aos from "aos";
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
