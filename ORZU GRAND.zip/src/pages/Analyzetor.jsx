import React from 'react'

function Analyzetor() {
  return (
    <div>Analyzetor</div>
  )
}

export default Analyzetor