import React from 'react'

function NewsPromotions() {
  return (
    <div>NewsPromotions</div>
  )
}

export default NewsPromotions