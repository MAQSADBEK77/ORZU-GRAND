import React from 'react'

function Servises() {
  return (
    <div>Servises</div>
  )
}

export default Servises