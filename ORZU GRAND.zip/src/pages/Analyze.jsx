import React from 'react'

function Analyze() {
  return (
    <div>Analyze</div>
  )
}

export default Analyze