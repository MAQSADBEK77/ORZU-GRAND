import React from 'react'

function OKompaniya() {
  return (
    <div>OKompaniya</div>
  )
}

export default OKompaniya